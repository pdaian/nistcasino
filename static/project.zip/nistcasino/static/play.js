window.do_play = function(game_type, game_id) {
    alert(1);
}
